1. Install dependencies:
   `npm install`
2. Set the `GEMINI_API_KEY` in [.env.example](.env.example) to your Gemini API key
3. Run the app:
   `npm run dev`
